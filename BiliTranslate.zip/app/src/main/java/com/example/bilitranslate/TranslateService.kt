package com.example.bilitranslate

import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.Icon
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioPlaybackCaptureConfiguration
import android.media.AudioRecord
import android.media.MediaRecorder
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.TextView
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.MultipartBody
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicInteger

class TranslateService : Service() {

    companion object {
        const val ACTION_STOP = "com.example.bilitranslate.STOP"
        const val EXTRA_CODE = "code"
        const val EXTRA_DATA = "data"
        const val EXTRA_KEY = "key"
        const val EXTRA_MIC = "mic"
        private const val SR = 16000
        private const val THRESH = 350.0      // loudness needed to count as "speech"
        private const val CHANNEL = "bili_translate"
        private val JUNK = setOf("thank you", "thanks for watching", "you", "bye")
    }

    private val main = Handler(Looper.getMainLooper())
    private val pending = AtomicInteger(0)
    private val client = OkHttpClient.Builder().callTimeout(30, TimeUnit.SECONDS).build()

    private var projection: MediaProjection? = null
    private var record: AudioRecord? = null
    private var sender: ExecutorService? = null
    private var wm: WindowManager? = null
    private var overlay: TextView? = null
    private var apiKey = ""
    @Volatile private var active = false

    private val hideRunnable = Runnable { overlay?.visibility = View.GONE }

    override fun onBind(intent: Intent?): IBinder? = null

    @Suppress("DEPRECATION")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (active) return START_NOT_STICKY

        apiKey = intent.getStringExtra(EXTRA_KEY).orEmpty()
        val useMic = intent.getBooleanExtra(EXTRA_MIC, false)

        createChannel()
        val type = if (useMic) ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE
        else ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION
        startForeground(1, buildNotification(), type)

        addOverlay()

        try {
            if (!useMic) {
                val code = intent.getIntExtra(EXTRA_CODE, 0)
                val data = intent.getParcelableExtra<Intent>(EXTRA_DATA)
                    ?: throw IllegalStateException("No capture permission")
                val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
                val mp = mpm.getMediaProjection(code, data)
                mp.registerCallback(object : MediaProjection.Callback() {
                    override fun onStop() { main.post { stopSelf() } }
                }, main)
                projection = mp
            }
            val rec = createRecord(useMic, projection)
            if (rec.state != AudioRecord.STATE_INITIALIZED) {
                throw IllegalStateException("Could not start audio capture")
            }
            record = rec
            sender = Executors.newSingleThreadExecutor()
            active = true
            Thread { captureLoop(rec) }.start()
            show("Listening... (drag me to move)")
        } catch (e: Exception) {
            show("Error: ${e.message}")
            main.postDelayed({ stopSelf() }, 5000)
        }
        return START_NOT_STICKY
    }

    @SuppressLint("MissingPermission")
    private fun createRecord(useMic: Boolean, mp: MediaProjection?): AudioRecord {
        val fmt = AudioFormat.Builder()
            .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
            .setSampleRate(SR)
            .setChannelMask(AudioFormat.CHANNEL_IN_MONO)
            .build()
        val min = AudioRecord.getMinBufferSize(
            SR, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT
        )
        val b = AudioRecord.Builder()
            .setAudioFormat(fmt)
            .setBufferSizeInBytes(maxOf(min, SR * 2))
        if (useMic) {
            b.setAudioSource(MediaRecorder.AudioSource.MIC)
        } else {
            b.setAudioPlaybackCaptureConfig(
                AudioPlaybackCaptureConfiguration.Builder(mp!!)
                    .addMatchingUsage(AudioAttributes.USAGE_MEDIA)
                    .addMatchingUsage(AudioAttributes.USAGE_GAME)
                    .addMatchingUsage(AudioAttributes.USAGE_UNKNOWN)
                    .build()
            )
        }
        return b.build()
    }

    /** Reads 100 ms frames, groups speech into sentence-sized chunks, sends each for translation. */
    private fun captureLoop(rec: AudioRecord) {
        val frame = ShortArray(SR / 10)
        val buf = ByteArrayOutputStream()
        var inSpeech = false
        var silent = 0
        var total = 0
        rec.startRecording()
        while (active) {
            val n = rec.read(frame, 0, frame.size)
            if (n < 0) break
            if (n == 0) continue
            var sum = 0.0
            for (i in 0 until n) sum += frame[i].toDouble() * frame[i]
            val loud = Math.sqrt(sum / n) > THRESH
            if (loud) { inSpeech = true; silent = 0 } else if (inSpeech) silent++
            if (!inSpeech) continue

            val bb = ByteBuffer.allocate(n * 2).order(ByteOrder.LITTLE_ENDIAN)
            bb.asShortBuffer().put(frame, 0, n)
            buf.write(bb.array())
            total++

            // end of sentence: 0.6 s of silence, or hard cap of 8 s
            if (silent >= 6 || total >= 80) {
                if (total - silent >= 8) submit(buf.toByteArray())
                buf.reset()
                inSpeech = false; silent = 0; total = 0
            }
        }
    }

    private fun submit(pcm: ByteArray) {
        val ex = sender ?: return
        if (pending.get() >= 3) return   // fell behind: drop to stay live
        pending.incrementAndGet()
        ex.execute {
            try {
                val t = translate(pcm)
                val clean = t.trim().lowercase().trimEnd('.', '!', '?', ' ')
                if (t.isNotBlank() && clean !in JUNK) show(t)
            } catch (e: Exception) {
                show("Error: ${e.message}")
            } finally {
                pending.decrementAndGet()
            }
        }
    }

    private fun translate(pcm: ByteArray): String {
        val body = MultipartBody.Builder().setType(MultipartBody.FORM)
            .addFormDataPart("file", "audio.wav", wav(pcm).toRequestBody("audio/wav".toMediaType()))
            .addFormDataPart("model", "whisper-large-v3")
            .addFormDataPart("response_format", "json")
            .addFormDataPart("temperature", "0")
            .build()
        val req = Request.Builder()
            .url("https://api.groq.com/openai/v1/audio/translations")
            .header("Authorization", "Bearer $apiKey")
            .post(body)
            .build()
        client.newCall(req).execute().use { r ->
            val s = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw IOException("HTTP ${r.code} ${s.take(100)}")
            return JSONObject(s).optString("text").trim()
        }
    }

    private fun wav(pcm: ByteArray): ByteArray {
        val bb = ByteBuffer.allocate(44 + pcm.size).order(ByteOrder.LITTLE_ENDIAN)
        bb.put("RIFF".toByteArray()); bb.putInt(36 + pcm.size); bb.put("WAVE".toByteArray())
        bb.put("fmt ".toByteArray()); bb.putInt(16)
        bb.putShort(1); bb.putShort(1)
        bb.putInt(SR); bb.putInt(SR * 2)
        bb.putShort(2); bb.putShort(16)
        bb.put("data".toByteArray()); bb.putInt(pcm.size); bb.put(pcm)
        return bb.array()
    }

    // ---------- overlay ----------

    @SuppressLint("ClickableViewAccessibility")
    private fun addOverlay() {
        val w = getSystemService(WINDOW_SERVICE) as WindowManager
        wm = w
        val tv = TextView(this).apply {
            setTextColor(Color.WHITE)
            textSize = 18f
            setTypeface(typeface, Typeface.BOLD)
            gravity = Gravity.CENTER
            setPadding(28, 14, 28, 14)
            setBackgroundColor(0xB0000000.toInt())
            text = "Starting..."
        }
        val lp = WindowManager.LayoutParams(
            (resources.displayMetrics.widthPixels * 0.92).toInt(),
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = 220
        }
        var startY = 0
        var downY = 0f
        tv.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { startY = lp.y; downY = e.rawY }
                MotionEvent.ACTION_MOVE -> {
                    lp.y = startY - (e.rawY - downY).toInt()
                    w.updateViewLayout(tv, lp)
                }
            }
            true
        }
        w.addView(tv, lp)
        overlay = tv
    }

    private fun show(text: String) {
        main.post {
            overlay?.let {
                it.text = text
                it.visibility = View.VISIBLE
                main.removeCallbacks(hideRunnable)
                main.postDelayed(hideRunnable, 6000)
            }
        }
    }

    // ---------- notification ----------

    private fun createChannel() {
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Live translation", NotificationManager.IMPORTANCE_LOW)
        )
    }

    private fun buildNotification(): Notification {
        val stop = PendingIntent.getService(
            this, 0,
            Intent(this, TranslateService::class.java).setAction(ACTION_STOP),
            PendingIntent.FLAG_IMMUTABLE
        )
        return Notification.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("Live translation is running")
            .setContentText("Tap Stop to end")
            .setOngoing(true)
            .addAction(
                Notification.Action.Builder(
                    Icon.createWithResource(this, android.R.drawable.ic_delete), "Stop", stop
                ).build()
            )
            .build()
    }

    override fun onDestroy() {
        active = false
        main.removeCallbacksAndMessages(null)
        try { record?.stop() } catch (_: Exception) {}
        try { record?.release() } catch (_: Exception) {}
        try { projection?.stop() } catch (_: Exception) {}
        sender?.shutdownNow()
        try { overlay?.let { wm?.removeView(it) } } catch (_: Exception) {}
        super.onDestroy()
    }
}
