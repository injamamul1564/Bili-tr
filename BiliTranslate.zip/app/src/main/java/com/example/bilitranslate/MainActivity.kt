package com.example.bilitranslate

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var keyInput: EditText
    private lateinit var micBox: CheckBox
    private val reqPerms = 1
    private val reqCapture = 2

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val pad = (20 * resources.displayMetrics.density).toInt()

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, pad)
        }

        fun label(t: String, size: Float, bold: Boolean = false) = TextView(this).apply {
            text = t
            textSize = size
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(0, pad / 2, 0, pad / 2)
        }

        root.addView(label("Bilibili Live Translator", 24f, true))
        root.addView(
            label(
                "Shows English subtitles over Bilibili live streams.\n\n" +
                    "1. Get a free API key at console.groq.com and paste it below.\n" +
                    "2. Press Start and allow the permissions.\n" +
                    "3. Bilibili opens; subtitles appear at the bottom. Drag them to move.\n" +
                    "4. Stop from the notification or this screen.",
                14f
            )
        )

        keyInput = EditText(this).apply {
            hint = "Groq API key (gsk_...)"
            setText(prefs.getString("key", ""))
            setSingleLine()
        }
        root.addView(keyInput)

        micBox = CheckBox(this).apply {
            text = "Use microphone instead (fallback if app audio capture is blocked)"
        }
        root.addView(micBox)

        root.addView(Button(this).apply {
            text = "Start translation"
            setOnClickListener { onStartClicked() }
        })
        root.addView(Button(this).apply {
            text = "Stop"
            setOnClickListener {
                stopService(Intent(this@MainActivity, TranslateService::class.java))
                toast("Stopped")
            }
        })

        val scroll = ScrollView(this).apply {
            addView(root)
            setOnApplyWindowInsetsListener { v, ins ->
                v.setPadding(0, ins.systemWindowInsetTop, 0, ins.systemWindowInsetBottom)
                ins
            }
        }
        setContentView(scroll)
    }

    private fun onStartClicked() {
        val key = keyInput.text.toString().trim()
        if (key.isEmpty()) {
            toast("Paste your Groq API key first")
            return
        }
        getSharedPreferences("cfg", MODE_PRIVATE).edit().putString("key", key).apply()

        if (!Settings.canDrawOverlays(this)) {
            toast("Turn on 'Display over other apps' for this app, then come back and press Start")
            startActivity(
                Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
            )
            return
        }

        val need = mutableListOf<String>()
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            need += Manifest.permission.RECORD_AUDIO
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) need += Manifest.permission.POST_NOTIFICATIONS
        if (need.isNotEmpty()) {
            requestPermissions(need.toTypedArray(), reqPerms)
            return
        }
        beginCapture()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == reqPerms) {
            if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED)
                beginCapture()
            else toast("Audio permission is required")
        }
    }

    private fun beginCapture() {
        if (micBox.isChecked) {
            startTranslating(0, null)
        } else {
            val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(mpm.createScreenCaptureIntent(), reqCapture)
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == reqCapture) {
            if (resultCode == RESULT_OK && data != null) startTranslating(resultCode, data)
            else toast("Audio capture was not allowed")
        }
    }

    private fun startTranslating(code: Int, data: Intent?) {
        val i = Intent(this, TranslateService::class.java)
            .putExtra(TranslateService.EXTRA_KEY, keyInput.text.toString().trim())
            .putExtra(TranslateService.EXTRA_MIC, micBox.isChecked)
            .putExtra(TranslateService.EXTRA_CODE, code)
        if (data != null) i.putExtra(TranslateService.EXTRA_DATA, data)
        startForegroundService(i)

        val biliIntent = listOf("com.bilibili.app.in", "tv.danmaku.bili", "com.bilibili.app.blue")
            .firstNotNullOfOrNull { packageManager.getLaunchIntentForPackage(it) }
        if (biliIntent != null) startActivity(biliIntent) else {
            toast("Open Bilibili now")
            moveTaskToBack(true)
        }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_LONG).show()
}
